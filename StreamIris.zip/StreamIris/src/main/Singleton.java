package main;

import org.apache.log4j.Logger;

import at.sti2.streamingiris.api.IKnowledgeBase;
public class Singleton {
	  private static Singleton singleton = null;
	  private static Logger logger = Logger.getRootLogger();
	  
	  private IKnowledgeBase kb = null;
	  private boolean loadedFirstTime = false;
	  
	  protected Singleton() {
	    // Exists only to defeat instantiation.
	  }
	  public static Singleton getInstance() {
	     if(singleton == null) {
	        singleton = new Singleton();
	        singleton.setLoadedFirstTime(true);
	     } else {
	    	 singleton.setLoadedFirstTime(false);
	     }
	     logger.info("loaded singleton for first time: " + singleton.isLoadedFirstTime());
	     logger.info("created singleton: " + singleton);
	     return singleton;
	  }
	  
	public IKnowledgeBase getKb() {
		return kb;
	}
	public void setKb(IKnowledgeBase kb) {
		this.kb = kb;
	}
	public boolean isLoadedFirstTime() {
		return loadedFirstTime;
	}
	public void setLoadedFirstTime(boolean loadedFirstTime) {
		this.loadedFirstTime = loadedFirstTime;
	}
	  
}