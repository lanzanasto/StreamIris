package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.sti2.streamingiris.Configuration;
import at.sti2.streamingiris.KnowledgeBaseFactory;
import at.sti2.streamingiris.api.IKnowledgeBase;
import at.sti2.streamingiris.api.basics.IPredicate;
import at.sti2.streamingiris.api.basics.IQuery;
import at.sti2.streamingiris.api.basics.IRule;
import at.sti2.streamingiris.api.terms.IVariable;
import at.sti2.streamingiris.storage.IRelation;

public class StreamingIris {
	
	// p(1). p(?n) :- p(?x), ?x + 1 = ?n, ?n <= 500. q(?x, ?y) :- p(?x), p(?y).
	public String loadKnowledgebase(String program) {
		
		String ret = "success";
		
		try {
		
			Singleton s = Singleton.getInstance();
			
			if(s.getKb() != null) {
				s.getKb().shutdown();
			}
			Configuration configuration = KnowledgeBaseFactory.getDefaultConfiguration();
			
			at.sti2.streamingiris.compiler.Parser parser = new at.sti2.streamingiris.compiler.Parser();
			parser.parse(program);
			Map<IPredicate, IRelation> facts = parser.getFacts();  List<IRule> 
			rules = parser.getRules();
			
			IKnowledgeBase knowledgeBase = KnowledgeBaseFactory.createKnowledgeBase(facts, rules, configuration);
			s.setKb(knowledgeBase);
		} catch(Exception ex) {
			ret = ex.toString();
		}
		
		return ret;
	}
	
	// ?- q(?x, ?y).
	public String executeQuery(String queryString) {
		
		String ret = "";
		
		try {
			IKnowledgeBase knowledgeBase = Singleton.getInstance().getKb();
			at.sti2.streamingiris.compiler.Parser parser = new at.sti2.streamingiris.compiler.Parser();
			parser.parse(queryString);
			
			// Execute a query
			for (IQuery query : parser.getQueries()) {  List<IVariable> 
				variableBindings = new ArrayList<IVariable>(); 
				IRelation result = knowledgeBase.execute(query, variableBindings);
				ret += variableBindings;
				
				// do something with the results
				// the variable bindings of the results are in the object "variableBindings" which was given as an argument to the method execute.
			}
		} catch(Exception ex) {
			ret = ex.toString();
		}
		
		return ret;
	}

}
